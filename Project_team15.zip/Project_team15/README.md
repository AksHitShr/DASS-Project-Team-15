# DASS PROJECT (TEAM-15)
## Client- Cyrrup Solutions Pvt. Ltd.
## RELEASE-1
### Team Members:
- Akshit Sharma (2021101029)
- Ishit Bansal (2021101083)
- Bhumika Joshi (2022121006)
- Aditya Padiyar (2021111002)

### In this release, we are showing the self-study and learning tasks we have done for the client in the last 2 months. The first month was used for learning about the client's app and the development tools needed for future tasks. We were assigned 3 tasks over the course of next month and each of us had to do them individually. The tasks were to create basic flutter apps to help us in getting familiarised with dart programming language as well as the android studio IDE. The submitted code has been contributed by the team members.
<br>

> For each task, we have submitted the lib folder, containing the main.dart file as well as the multiple pages of the app (task-3), along with the pubsec.yaml file and the assets used like images. The other files used in the apps are common to all.

> Task-1:
  Making a Hello World app in Flutter with an navbar,image and a button, which when clicked, shows an alert and a message.

> Task-2:
  Making a flutter app with a text input field, allowing users to enter text and converting it into speech on press of submit button. Implemented using flutter_tts package. Implemented speech output in local languages like Hindi and Telugu as well as English. 

> Task-3:
  Making a flutter app with multiple navigatable screens and vehicle options on a particular screen which announces vehicle information on clicking along with a pop-up/alert for the vehicle.